import * as React from "react";
import "./App.css";
import { SpreadsheetComponent } from "@syncfusion/ej2-react-spreadsheet";
import { useRef, useEffect } from "react";
import { TableTitle } from './table-titles/TableTitles';

const App = () => {
  const sheetRef = useRef();


  // const movetoExcel1 = () => {
  //   sheetRef.current.updateCell({ value: "variable1" }, "A3");
  // };
  // const movetoExcel2 = () => {
  //   sheetRef.current.updateCell({ value: "variable2" }, "A4");
  // };
  // const movetoExcel3 = () => {
  //   sheetRef.current.updateCell({ value: "variable3" }, "A5");
  // };
  // const movetoExcel4 = () => {
  //   sheetRef.current.updateCell({ value: "variable4" }, "A6");
  // };
  // const movetoExcel5 = () => {
  //   sheetRef.current.updateCell({ value: "variable5" }, "A7");
  // };

  useEffect(() => {
    // Set the initial active cell to B2
    sheetRef.current.activeCell = 'B1';
  }, []);
  const handleAddTitles = (item,index) => {
    sheetRef.current.updateCell({ value: item.title }, `A${index+1}`);
    sheetRef.current.cellFormat({ fontWeight: 'bold', textAlign: 'left', width: 120 }, `A${index + 1}`)
    if (item.title == "Sum"){
      sheetRef.current.updateCell({ formula: `=SUM(B${1}: B${4})` }, `B${index + 1}`);
      sheetRef.current.cellFormat({ fontWeight: 'bold', textAlign: 'left', width: 120,color:"red" }, `B${index + 1}`)
      
    }
  }

  return (
    <div className="App">
      <div className="mainPanel">
        <div className="panelOne">
          <SpreadsheetComponent
            ref={(s) => {
              sheetRef.current = s;
            }}
            allowOpen={true}
            openUrl="https://ej2services.syncfusion.com/production/web-services/api/spreadsheet/open"
            allowSave={true}
          />
        </div>
        <div className="panelTwo">
          <h1>Finding Interset</h1>
          {TableTitle?.map((item, index) => (
            <h4 className={"table-title"} onClick={() => handleAddTitles(item,index)}>
              {item.title}
            </h4>
          ))}
        </div>
      </div>
    </div>
  );
};

export default App;
