export const TableTitle = [
    {
        id: 1,
        title: "Interest Amount"
    },
    {
        id: 2,
        title: "Principle Amount"
    },
    {
        id: 3,
        title: "Time period"

    },
     {
        id: 4,
        title: "Interest rate"
    },
    {
        id:5,
        title: "Sum"
    }

]