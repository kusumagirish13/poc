import * as React from "react";
import "./App.css";
import { SpreadsheetComponent } from "@syncfusion/ej2-react-spreadsheet";
import { useRef } from "react";

const App = () => {
  const sheetRef = useRef();

  const movetoExcel1 = () => {
    sheetRef.current.updateCell({ value: "variable1" }, "A3");
  };
  const movetoExcel2 = () => {
    sheetRef.current.updateCell({ value: "variable2" }, "A4");
  };
  const movetoExcel3 = () => {
    sheetRef.current.updateCell({ value: "variable3" }, "A5");
  };
  const movetoExcel4 = () => {
    sheetRef.current.updateCell({ value: "variable4" }, "A6");
  };
  const movetoExcel5 = () => {
    sheetRef.current.updateCell({ value: "variable5" }, "A7");
  };

  return (
    <div className="App">
      <div className="mainPanel">
        <div className="panelOne">
          <SpreadsheetComponent
            ref={(s) => {
              sheetRef.current = s;
            }}
            allowOpen={true}
            openUrl="https://ej2services.syncfusion.com/production/web-services/api/spreadsheet/open"
            allowSave={true}
          />
        </div>
        <div className="panelTwo">
          <p>
            <a onClick={movetoExcel1} className="textLink">
              variable1
            </a>
          </p>
          <p>
            <a onClick={movetoExcel2} className="textLink">
              Variable2
            </a>
          </p>
          <p>
            <a onClick={movetoExcel3} className="textLink">
              Variable3
            </a>
          </p>
          <p>
            <a onClick={movetoExcel4} className="textLink">
              Variable4
            </a>
          </p>
          <p>
            <a onClick={movetoExcel5} className="textLink">
              Variable5
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default App;
